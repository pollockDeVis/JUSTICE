# -*- coding: utf-8 -*-
"""
Created on Wed Mar  6 13:45:43 2024

@author: apoujon
"""

import numpy as np
import pandas as pd
from typing import Any
import copy

from src.exploration.DataLoaderTwoLevelGame import XML_init_values
from src.exploration.LogFiles import LogFiles, print_log
from src.util.data_loader import DataLoader
from src.util.enumerations import Economy, DamageFunction, Abatement, WelfareFunction
from src.util.model_time import TimeHorizon
from src.economy.neoclassical import NeoclassicalEconomyModel
from src.emissions.emission import OutputToEmissions
from src.damage.kalkuhl import DamageKalkuhl
from src.climate.coupled_fair import CoupledFAIR
from src.climate.temperature_downscaler import TemperatureDownscaler
from src.abatement.abatement_enerdata import AbatementEnerdata
from src.exploration.twolevelsgame import TwoLevelsGame
from src.exploration.household import Household
from src.model import JUSTICE
from src.JusticeProjection import JusticeProjection


class Information:

    def __init__(
        self,
        justice_model,
        start_year=2015,  # Model is only tested for start year 2015
        end_year=2300,  # Model is only tested for end year 2300
        timestep=1,  # Model is only tested for timestep 1
        scenario=0,
        climate_ensembles=None,
        economy_type=Economy.NEOCLASSICAL,
        damage_function_type=DamageFunction.KALKUHL,
        abatement_type=Abatement.ENERDATA,
        social_welfare_function=WelfareFunction.UTILITARIAN,
        **kwargs,
    ):

        self.justice_model = justice_model

        # self.elasticity_of_marginal_utility_of_consumption = 1.45
        # self.pure_rate_of_social_time_preference = 0.015
        # self.inequality_aversion = 0

        self.IPCC_report_period = XML_init_values.dict["IPCC_report_period"]

        # TODO APN: Change to numpy arrays
        self.global_temperature_information = []
        # Last known forecast by FaIR (every Y years) under the form [year; mean_temperature; var_temperature]
        self.local_temperature_information = []
        # Last know forecast by JUSTICE
        self.local_economic_damage_information = []
        self.maximum_damage_information = []
        # Last known downscaled forecast by FaIr (every 10 years) under the forme [year; mean_temperature; var_temperature] for each region
        self.global_distrib_flsi = np.empty(
            [
                Household.N_CLIMATE_BELIEFS,
                int(
                    (Household.DISTRIB_MAX_VALUE - Household.DISTRIB_MIN_VALUE)
                    / Household.DISTRIB_RESOLUTION
                ),
            ]
        )
        # Estimations of future temperature elevation (ground) at global scale at future years BELIEF_YEAR_OFFSET
        self.regional_distrib_flsi = [
            [
                np.empty(
                    [
                        Household.N_CLIMATE_BELIEFS,
                        int(
                            (Household.DISTRIB_MAX_VALUE - Household.DISTRIB_MIN_VALUE)
                            / Household.DISTRIB_RESOLUTION
                        ),
                    ]
                )
            ]
            for r in range(57)
        ]

        # Estimations of future temperature elevation (ground) at local scale at future years BELIEF_YEAR_OFFSET
        # TODO APN: 57 is the number of regions: use global var or get from JUSTICE model

        self.global_temperature_projection1 = []
        self.local_temperature_projection1 = []
        self.local_consumption_per_capita1 = []
        self.global_temperature_projection2 = []
        self.local_temperature_projection2 = []
        self.local_consumption_per_capita2 = []
        self.global_temperature_projection3 = []
        self.local_temperature_projection3 = []
        self.local_consumption_per_capita3 = []

    def step(self, timestep):

        # TODO APN: don't use timestep as it may not correspond 1::1 to a year increment
        if timestep % self.IPCC_report_period == 0:
            self.generate_information()
        self.construct_flsi(timestep)

        return

    def generate_projections(self, time_step, regions):
        """
        Take into account a JUSTICE model and future emissions control rate for all regions.
        Return the full set of data for the execution of the JUSTICE model over 5 years under these conditions.
        Is used in the model a a source of information (eg. similar to an IPCC report)

        Parameters
        ----------
        justice_model : TYPE
            DESCRIPTION. A deepcopy of the current JUSTICE model
        emissions_control_rate : TYPE
            DESCRIPTION. array: region * time horizon array

        Returns
        -------
        None.

        """

        # Get a fresh model
        # information_model = JUSTICE()
        print("      -> RUNNING PROJECTION MODEL")
        projection_model_base = JusticeProjection(self.justice_model)
        projection_model_support = JusticeProjection(self.justice_model)
        projection_model_opposition = JusticeProjection(self.justice_model)

        ecr1 = []
        ecr2 = []
        ecr3 = []

        for i in range(time_step, time_step + 5):
            projection_model_base.stepwise_run(
                ecr1[:, i], timestep=i, endogenous_savings_rate=True
            )  # savings_rate = fixed_savings_rate[:, timestep],
            projection_model_support.stepwise_run(
                ecr2[:, i], timestep=i, endogenous_savings_rate=True
            )  # savings_rate = fixed_savings_rate[:, timestep],
            projection_model_opposition.stepwise_run(
                ecr3[:, i], timestep=i, endogenous_savings_rate=True
            )  # savings_rate = fixed_savings_rate[:, timestep],
            datasets_base = projection_model_base.stepwise_evaluate(timestep=i)
            datasets_support = projection_model_support.stepwise_evaluate(timestep=i)
            datasets_opposition = projection_model_opposition.stepwise_evaluate(
                timestep=i
            )

        means_global_temp = datasets_base["global_temperature"].mean(axis=1)
        std_global_temp = datasets_base["global_temperature"].std(axis=1)
        self.global_temperature_projection1 = [means_global_temp, std_global_temp]
        means_local_temp = datasets_base["regional_temperature"].mean(axis=2)
        std_local_temp = datasets_base["regional_temperature"].std(axis=2)
        self.local_temperature_projection1 = [means_local_temp, std_local_temp]
        self.local_consumption_per_capita1 = datasets_base["consumption"].mean(axis=2)

        means_global_temp = datasets_support["global_temperature"].mean(axis=1)
        std_global_temp = datasets_support["global_temperature"].std(axis=1)
        self.global_temperature_projection2 = [means_global_temp, std_global_temp]
        means_local_temp = datasets_support["regional_temperature"].mean(axis=2)
        std_local_temp = datasets_support["regional_temperature"].std(axis=2)
        self.local_temperature_projection2 = [means_local_temp, std_local_temp]
        self.local_consumption_per_capita2 = datasets_support["consumption"].mean(
            axis=2
        )

        means_global_temp = datasets_opposition["global_temperature"].mean(axis=1)
        std_global_temp = datasets_opposition["global_temperature"].std(axis=1)
        self.global_temperature_projection3 = [means_global_temp, std_global_temp]
        means_local_temp = datasets_opposition["regional_temperature"].mean(axis=2)
        std_local_temp = datasets_opposition["regional_temperature"].std(axis=2)
        self.local_temperature_projection3 = [means_local_temp, std_local_temp]
        self.local_consumption_per_capita3 = datasets_opposition["consumption"].mean(
            axis=2
        )

        print(
            "         L> PROJECTION DONE!",
        )

        # print(datasets["consumption_per_capita"])
        return

    def generate_information(self):
        """
        Take into account a JUSTICE model and future emissions control rate for all regions.
        Return the full set of data for the execution of the JUSTICE model under these conditions.
        Is used in the model a a source of information (eg. similar to an IPCC report)

        Parameters
        ----------
        justice_model : TYPE
            DESCRIPTION. A deepcopy of the current JUSTICE model
        emissions_control_rate : TYPE
            DESCRIPTION. array: region * time horizon array

        Returns
        -------
        None.

        """

        # Get a fresh model
        # information_model = JUSTICE()
        print("      -> RUNNING INFORMATION MODEL")
        information_model = JusticeProjection(self.justice_model)
        information_model.run(
            emission_control_rate=self.justice_model.emission_control_rate,
            endogenous_savings_rate=True,
        )
        datasets = (
            information_model.evaluate()
        )  # Might be useful to just create an evaluation function for the relevant information only
        self.generate_climate_information(
            datasets["global_temperature"], datasets["regional_temperature"]
        )
        self.generate_loss_and_damage_information(
            datasets["economic_damage"], datasets["net_economic_output"]
        )

        # print(datasets["consumption_per_capita"])
        return

    def generate_climate_information(self, g_temp, l_temp):
        # g_temp An array of time horizon * number of ensembles
        # l_temp An array of size regions * time horizon * number of ensembles

        # Global Temperatures: expected means and variances
        means_global_temp = g_temp.mean(axis=1)
        # array of shape time horizon
        std_global_temp = g_temp.std(axis=1)
        # array of shape time horizon
        self.global_temperature_information = [means_global_temp, std_global_temp]
        # array of shape  2 * time_horizon

        # Local Temperatures: expected means and variances
        means_local_temp = l_temp.mean(axis=2)
        # array of shape region * time horizon
        std_local_temp = l_temp.std(axis=2)
        # array of shape region * time horizon
        self.local_temperature_information = [means_local_temp, std_local_temp]
        # array of shape  2 * region * time_horizon
        return

    def generate_loss_and_damage_information(self, l_dmg, l_net_gdp):
        l_rel_dmg = l_dmg / (l_dmg + l_net_gdp)
        mean_dmg = l_rel_dmg.mean(axis=2)
        mean_dmg_truncated = mean_dmg[:][:86]
        ind_worst_region = np.argmax(np.sum(mean_dmg_truncated, 1))
        max_mean_dmg = mean_dmg_truncated[ind_worst_region][:]
        std_dmg = l_rel_dmg.std(axis=2)
        self.local_economic_damage_information = [mean_dmg_truncated, std_dmg[:][:86]]
        self.maximum_damage_information = [
            max_mean_dmg,
            std_dmg[ind_worst_region][:86],
        ]

        for r in range(57):
            dmg = self.local_economic_damage_information[0][r]
            print_log.f_information[1].writerow([0, r] + [d for d in dmg])
        return

    def construct_flsi(self, timestep):
        # Global
        for i in range(Household.N_CLIMATE_BELIEFS):
            year = Household.BELIEF_YEAR_OFFSET[i]
            if year != -1 and year > timestep:
                # Look at maximum temperature elevation from "2015+current" to 2015+year
                i_max_temp = np.argmax(
                    self.global_temperature_information[0][timestep:year]
                )
                self.global_distrib_flsi[i] = Household.gaussian_distrib(
                    g_mean=self.global_temperature_information[0][i_max_temp],
                    g_std=self.global_temperature_information[1][i_max_temp],
                )
                print_log.write_log(
                    LogFiles.MASKLOG_Information,
                    "information.py",
                    "construct_flsi",
                    f"""Maximum mean temperature increase is \
{self.global_temperature_information[0][i_max_temp]:0.2f} \
at year \
{2015+i_max_temp} \
with std \
{self.global_temperature_information[1][i_max_temp]}""",
                )
            else:
                # Look at the current temperature elevation
                self.global_distrib_flsi[i] = Household.gaussian_distrib(
                    g_mean=self.global_temperature_information[0][timestep],
                    g_std=self.global_temperature_information[1][timestep],
                )
            norm_coeff = np.sum(self.global_distrib_flsi[i], axis=0)
            self.global_distrib_flsi[i] = self.global_distrib_flsi[i] / norm_coeff
            print_log.write_log(
                LogFiles.MASKLOG_Information,
                "information.py",
                "construct_flsi",
                f"normalization coefficient for distribution = {norm_coeff:0.3f}",
            )

        # Local
        for r in range(57):
            for i in range(Household.N_CLIMATE_BELIEFS):
                year = Household.BELIEF_YEAR_OFFSET[i]
                if year != -1 and year > timestep:
                    i_max_temp = np.argmax(
                        self.local_temperature_information[0][r][timestep:year]
                    )
                    self.regional_distrib_flsi[r][0][i] = Household.gaussian_distrib(
                        g_mean=self.local_temperature_information[0][r][i_max_temp],
                        g_std=self.local_temperature_information[1][r][i_max_temp],
                    )
                else:
                    self.regional_distrib_flsi[r][0][i] = Household.gaussian_distrib(
                        g_mean=self.local_temperature_information[0][r][timestep],
                        g_std=self.local_temperature_information[1][r][timestep],
                    )
                norm_coeff = np.sum(self.regional_distrib_flsi[r][0][i], axis=0)
                # TODO NOT SURE ABOUT THE COMPUTATION OF NORM COEFF HERE
                self.regional_distrib_flsi[r][0][i] = (
                    self.regional_distrib_flsi[r][0][i] / norm_coeff
                )

        return
