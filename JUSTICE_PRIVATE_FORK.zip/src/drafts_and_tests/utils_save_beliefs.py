import numpy as np
import csv
import pandas as pd
import glob
import matplotlib.pyplot as plt
from matplotlib import cm

# "../../data/output/SAVE_2024_03_13_2004/"
path_list = glob.glob("../../data/output/SAVE_2024_10_04_1538")
# print(path_list)
for save_path in path_list:
    print(save_path)
    f = open(save_path + "\parameters.txt", "r")
    print("\t" + f.read())
    df = pd.read_csv(save_path + "\household_beliefs.csv", header=0, dtype="float64")

    region = 32
    # household = 1
    fig = plt.figure()
    ax = fig.add_subplot(111)
    region_mask = df["Region"] == region
    df_region = df[region_mask]
    for household in range(100):

        household_mask = df_region["Household ID"] == household
        df_region_hh = df_region[household_mask]

        beliefs_hh = df_region_hh[df_region_hh.columns[3:]]
        timesteps_hh = df_region_hh[df_region_hh.columns[0]]

        beliefs_array = beliefs_hh.values

        # Create a meshgrid for plotting
        X, Y = np.meshgrid(np.arange(beliefs_array.shape[0]), np.arange(-2, 8, 0.1))

        # Create a figure and an axes object for the 3D plot

        # Plot the surface
        surf = ax.pcolor(
            X + 2015,
            Y,
            beliefs_array.transpose(),
            cmap=cm.viridis,
            alpha=beliefs_array.transpose(),
        )

    rect = lambda color: plt.Rectangle((0, 0), 1, 1, color=color)
    legend = ax.legend([rect(cm.viridis(1000)), rect(cm.viridis(0))], ["high confidence", "low confidence"])

    # Set labels and title

    ax.set_title("Superposed Beliefs on Maximum Temperature Increase\n(region "+str(region)+"; 100 households)")
    ax.set_ylabel("Expected Temperature Increase")
    ax.set_xlabel("Years")

    # Add a color bar
    fig.colorbar(surf, shrink=0.5, aspect=5)


plt.show()
